package com.example.myquizapplication;

public class Score {
    public Integer scoreBees;

    public Integer getScoreBees() {
        return scoreBees;
    }

    public void setScoreBees(Integer scoreBees) {
        this.scoreBees = scoreBees;
    }


}
