package com.example.myquizapplication;

public class QuestionAnswer_Level_1 {

    public static String questions[] = {
        "Wofür stehen die Siegel der Anbauverbände",
        "Frage 2 B Richtig",
        "Frage 3 C Richtig",
        "Frage 4 D Richtig",
        "Frage 5 D Richtig",
        "Frage 6 D Richtig",
        "Frage 7 D Richtig",
        "Frage 8 D Richtig",
        "Frage 9 D Richtig",
        "Frage 10 D Richtig",
    };

    public static String choices[][] = {
            {"konventionelle Futtermittel dürfen in einem sehr begrenzen Rahmen zugefüttert werden",
                    "Die Anbauverbände verlangen, dass der Betrieb komplett ökologisch arbeitet",
                    "Die Anbauverbände verlangen, dass der Betrieb teilweise ökologisch arbeitet",
                    "Wesentlich mehr Tiere je Hektar als das EU-Siegel"},

            {"A","B","C","D"},
            {"A","B","C","D"},
            {"A","B","C","D"},
            {"A","B","C","D"},
            {"A","B","C","D"},
            {"A","B","C","D"},
            {"A","B","C","D"},
            {"A","B","C","D"},
            {"A","B","C","D"},

    };

    public static String correctAnswers[] = {
            "B",
            "B",
            "C",
            "D",
            "D",
            "D",
            "D",
            "D",
            "D",
            "D",

    };

}
